package com.shem.autocaption

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme()) { Surface { Screen() } } }
    }
}

@Composable
fun Screen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var video by remember { mutableStateOf<File?>(null) }
    var srt by remember { mutableStateOf<File?>(null) }
    var style by remember { mutableStateOf(STYLES.keys.first()) }
    var status by remember { mutableStateOf("Ready") }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { runCatching { Pipeline.init(ctx) } } }

    fun run(label: String, block: suspend () -> Unit) = scope.launch {
        busy = true; status = label
        try { withContext(Dispatchers.IO) { block() } } catch (e: Throwable) { status = "Error: ${e.message}" }
        busy = false
    }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) run("Loading video…") { video = Pipeline.copyIn(ctx, u, "video_up.mp4"); status = "Video loaded" }
    }
    val pickSrt = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) run("Loading subtitles…") {
            srt = Pipeline.copyIn(ctx, u, "sub.srt"); caption = Pipeline.caption(srt!!); status = "Subtitles loaded"
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AutoCaption", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), label = { Text("YouTube / Facebook link") }, singleLine = true)
        Button({ run("Downloading…") { video = Pipeline.download(ctx, url.trim()); status = "Downloaded" } },
            Modifier.fillMaxWidth(), enabled = !busy && url.isNotBlank()) { Text("Download from link") }
        OutlinedButton({ pickVideo.launch("video/*") }, Modifier.fillMaxWidth(), enabled = !busy) { Text("Upload video (any format)") }
        OutlinedButton({ pickSrt.launch("*/*") }, Modifier.fillMaxWidth(), enabled = !busy) { Text("Add subtitle file (.srt)") }
        Text("Subtitle style"); 
        STYLES.keys.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { s -> FilterChip(style == s, { style = s }, { Text(s) }) } } }
        Button({ run("Burning subtitles…") { val o = Pipeline.burn(ctx, video!!, srt!!, style); status = "Saved: ${o.absolutePath}" } },
            Modifier.fillMaxWidth(), enabled = !busy && video != null && srt != null) { Text("Create video") }
        Text(status, style = MaterialTheme.typography.bodySmall)
        if (caption.isNotEmpty()) {
            OutlinedTextField(caption, { caption = it }, Modifier.fillMaxWidth(), label = { Text("FB caption + hook") })
            OutlinedButton({ (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("caption", caption)) }, Modifier.fillMaxWidth()) { Text("Copy caption") }
        }
    }
}
