package com.shem.autocaption

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

// ASS/force_style presets for the ffmpeg "subtitles" filter. Add more freely.
val STYLES = linkedMapOf(
    "Classic box" to "FontSize=22,BorderStyle=3,Outline=1,Shadow=0,BackColour=&H80000000,Alignment=2",
    "Bold outline" to "FontSize=26,Bold=1,Outline=3,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Alignment=2",
    "Yellow pop" to "FontSize=28,Bold=1,Outline=3,PrimaryColour=&H0000FFFF,OutlineColour=&H00000000,Alignment=2",
    "Neon" to "FontSize=26,Bold=1,Outline=2,PrimaryColour=&H00FFFF00,OutlineColour=&H00FF00FF,Shadow=2,Alignment=2",
    "Center big" to "FontSize=34,Bold=1,Outline=4,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Alignment=5",
    "Top" to "FontSize=24,Bold=1,Outline=3,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Alignment=8"
)

object Pipeline {
    fun init(ctx: Context) {
        YoutubeDL.getInstance().init(ctx); FFmpeg.getInstance().init(ctx)
        runCatching { YoutubeDL.getInstance().updateYoutubeDL(ctx) } // newest yt-dlp fixes most "sign in" blocks
    }

    private fun work(ctx: Context) = File(ctx.cacheDir, "work").apply { mkdirs() }

    // YouTube / Facebook (public) links via yt-dlp
    fun download(ctx: Context, url: String): File {
        val dir = work(ctx); dir.listFiles()?.filter { it.name.startsWith("video.") }?.forEach { it.delete() }
        val r = YoutubeDLRequest(url)
        r.addOption("-o", "${dir.absolutePath}/video.%(ext)s")
        r.addOption("-f", "bv*+ba/b")
        r.addOption("--merge-output-format", "mp4")
        r.addOption("--no-playlist")
        r.addOption("--force-ipv4")
        r.addOption("--extractor-args", "youtube:player_client=android_vr,tv,web_safari")
        YoutubeDL.getInstance().execute(r)
        return dir.listFiles()!!.first { it.name.startsWith("video.") }
    }

    // Any uploaded file (ffmpeg reads all common formats)
    fun copyIn(ctx: Context, uri: Uri, name: String): File {
        val f = File(work(ctx), name)
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    fun edit(ctx: Context, video: File, srt: File?, style: String, vertical: Boolean, fade: Boolean): File {
        val out = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "edited_${System.currentTimeMillis()}.mp4")
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        val f = mutableListOf<String>()
        if (vertical) f += "split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[bg];" +
            "[b]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2"
        if (srt != null) f += "subtitles=${srt.absolutePath}:force_style='${STYLES[style]}'"
        if (fade) f += "fade=t=in:st=0:d=0.5"
        val cmd = mutableListOf(bin.path, "-y", "-i", video.path, "-vf", if (f.isEmpty()) "null" else f.joinToString(","))
        if (fade) cmd += listOf("-af", "afade=t=in:d=0.5") else cmd += listOf("-c:a", "copy")
        cmd += listOf("-pix_fmt", "yuv420p", out.path)
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val log = p.inputStream.bufferedReader().readText()
        if (p.waitFor() != 0) error("ffmpeg failed: " + log.takeLast(400))
        return out
    }

    // Free, template-based Taglish hook + FB caption from the subtitle text
    fun caption(srt: File): String {
        val text = srt.readLines().filter { it.isNotBlank() && !it.contains("-->") && it.trim().toIntOrNull() == null }
            .joinToString(" ")
        val first = text.split(Regex("(?<=[.!?])\\s+")).firstOrNull { it.length > 15 }?.take(110) ?: text.take(110)
        val stop = setOf("yung", "kasi", "naman", "para", "dito", "talaga", "pero", "ang", "mga", "that", "this", "with", "have", "from", "what", "your", "they", "there")
        val tags = text.lowercase().split(Regex("[^\\p{L}]+")).filter { it.length > 4 && it !in stop }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(4).map { "#" + it.key }
        return "😱 Hindi mo ma-e-expect 'to!\n\n\"$first...\"\n\nPanoorin hanggang dulo — may matututunan ka. 👇\n\n" +
            "💬 I-comment ang iniisip mo, at i-share sa taong kailangan nito!\n\n" + tags.joinToString(" ") + " #fyp #reels"
    }
}
