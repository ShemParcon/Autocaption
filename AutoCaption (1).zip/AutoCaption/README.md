# AutoCaption (Stage 1)
1. github.com → New repository (Public = free build minutes) → "uploading an existing file".
2. Unzip this file on your phone/computer and upload ALL contents (keep the .github folder).
3. Open the repo → Actions tab → "Build APK" → wait ~5-8 min for green check.
4. Open the finished run → Artifacts → AutoCaption-apk → download, unzip, install the .apk (allow "install unknown apps").
If the build is red, open the run, copy the error text and send it to Claude.
